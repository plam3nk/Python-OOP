import unittest
from bookstore import Bookstore


class TestBookstore(unittest.TestCase):

    def setUp(self):
        self.bookstore = Bookstore(100)

    def test_receive_book(self):
        self.assertEqual(self.bookstore.receive_book("The Great Gatsby", 10),
                         "10 copies of The Great Gatsby are available in the bookstore.")
        self.assertEqual(self.bookstore.receive_book("To Kill a Mockingbird", 20),
                         "20 copies of To Kill a Mockingbird are available in the bookstore.")
        with self.assertRaises(Exception):
            self.bookstore.receive_book("Animal Farm", 90)  # should raise exception due to books limit reached

    def test_sell_book(self):
        self.bookstore.receive_book("The Catcher in the Rye", 5)
        self.assertEqual(self.bookstore.sell_book("The Catcher in the Rye", 3),
                         "Sold 3 copies of The Catcher in the Rye")
        with self.assertRaises(Exception):
            self.bookstore.sell_book("The Catcher in the Rye",
                                     4)  # should raise exception due to not enough copies available
        with self.assertRaises(Exception):
            self.bookstore.sell_book("1984", 2)  # should raise exception due to book not existing in store

    def test_total_sold_books(self):
        self.bookstore.receive_book("The Lord of the Rings", 10)
        self.bookstore.sell_book("The Lord of the Rings", 5)
        self.assertEqual(self.bookstore.total_sold_books, 5)

    def test_str(self):
        self.bookstore.receive_book("Pride and Prejudice", 15)
        self.bookstore.sell_book("Pride and Prejudice", 7)
        expected_result = "Total sold books: 7\nCurrent availability: 8\n - Pride and Prejudice: 8 copies"
        self.assertEqual(str(self.bookstore), expected_result)


if __name__ == '__main__':
    unittest.main()